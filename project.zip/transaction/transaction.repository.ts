import { EntityRepository, Repository } from 'typeorm';
import { Transaction } from './entities/transaction.entity'; // Transaction entity import

@EntityRepository(Transaction)
export class TransactionRepository extends Repository<Transaction> {
  // Example: Find transactions by category
  async findByCategory(categoryId: number): Promise<Transaction[]> {
    return this.find({ where: { category: { id: categoryId } } });
  }
}
