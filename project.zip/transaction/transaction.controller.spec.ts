import { Controller, Get, Post, Param, Body } from '@nestjs/common';
import { TransactionService } from './transaction.service'; // Service import
import { Transaction } from './entities/transaction.entity'; // Entity import

@Controller('transactions')
export class TransactionController {
  constructor(private readonly transactionService: TransactionService) {}

  // Get transactions by category
  @Get('category/:categoryId')
  async getTransactionsByCategory(
    @Param('categoryId') categoryId: number,
  ): Promise<Transaction[]> {
    return this.transactionService.findTransactionsByCategory(categoryId);
  }

  // Create a new transaction
  @Post()
  async createTransaction(
    @Body() createTransactionDto: { description: string; amount: number; categoryId: number; date: Date },
  ): Promise<Transaction> {
    const { description, amount, categoryId, date } = createTransactionDto;
    return this.transactionService.createTransaction(description, amount, categoryId, date);
  }
}
