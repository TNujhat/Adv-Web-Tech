import { Module } from '@nestjs/common';
import { TypeOrmModule } from '@nestjs/typeorm';
import { TransactionService } from './transaction.service'; // Service import
import { TransactionController } from './transaction.controller'; // Controller import
import { Transaction } from './entities/transaction.entity'; // Transaction entity import
import { TransactionRepository } from './transaction.repository'; // Repository import

@Module({
  imports: [TypeOrmModule.forFeature([Transaction, TransactionRepository])], // Repository import
  providers: [TransactionService],
  controllers: [TransactionController],
})
export class TransactionModule {}
