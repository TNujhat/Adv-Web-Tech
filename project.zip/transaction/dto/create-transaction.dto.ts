export class CreateTransactionDto {
    description: string;
    amount: number;
    category: number;
    date: Date;
  }
  